﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoMapper2.Model
{
    public class RootObjectDTO
    {
        public int Patientage { get; set; }
        public string Patientname { get; set; }
        public List<Drug> Drugs { get; set; }
    }
}

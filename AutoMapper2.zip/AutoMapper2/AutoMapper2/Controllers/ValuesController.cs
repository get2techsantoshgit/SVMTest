﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper2.Model;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapper2.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly IMapper _mapper;
        public ValuesController(IMapper mapper)
        {
            _mapper = mapper;
        }

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            SqlConnection con = new SqlConnection(@"Data source=SANTOSHOFFICIAL;Initial Catalog = EmployeeDB;Integrated Security = True");
            if(con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            List<Shop> Shop1 = con.Query<Shop>("Select * from shop").ToList();
            List<Account> Account1 = con.Query<Account>("Select * from Account").ToList();

            var response = new List<Account>();

            foreach (var sh in Shop1)
            {
                foreach (var acc in Account1)
                {
                    if (sh.Id == acc.Id)
                    {
                        sh.accounts.Add(acc);
                    }
                }
               
            }
            //ar data = _mapper.Map<ShopDTO>(Shop1);

            return Ok(Shop1);
            
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

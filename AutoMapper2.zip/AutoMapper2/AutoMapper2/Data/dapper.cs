﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoMapper2.Data
{
    public class dapper
    {

//        var lookup = new Dictionary<int, Shop>()
//conn.Query<Shop, Account, Shop>(@"
//                    SELECT s.*, a.*
//                    FROM Shop s
//                    INNER JOIN Account a ON s.ShopId = a.ShopId                    
//                    ", (s, a) => {
//                         Shop shop;
//                         if (!lookup.TryGetValue(s.Id, out shop)) {
//                             lookup.Add(s.Id, shop = s);
//                         }
//                         if (shop.Accounts == null) 
//                             shop.Accounts = new List<Account>();
//                         shop.Accounts.Add(a);
//                         return shop;
//                     },
//                     ).AsQueryable();

//var resultList = lookup.Values;
    }


}

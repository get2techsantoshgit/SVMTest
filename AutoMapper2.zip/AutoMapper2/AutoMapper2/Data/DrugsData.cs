﻿using AutoMapper2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoMapper2.Data
{
    public class DrugsData
    {
        public List<Drug> getDatadrugs()
        {
            return new List<Drug>
            {
                new Drug {DrugName ="First",Dosage = "1", MedicationDuration ="3", MedicationType ="type1"},
                new Drug {DrugName ="Second",Dosage = "2", MedicationDuration ="2", MedicationType ="type2"},
                new Drug {DrugName ="Third",Dosage = "3", MedicationDuration ="3", MedicationType ="type3"},
            };
        }
    }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ReadComponent } from './read/read.component';
import { WriteComponent } from './write/write.component';

import { StoreModule } from '@ngrx/store';
import { employeeReducer } from './statemanagement/reducers/employee.reducer'; 
import { EffectsModule } from '@ngrx/effects';
import { EmployeeEffects } from './statemanagement/effects/employee.effect';

import { HttpClientModule } from '@angular/common/http';
import { BEComponentComponent } from './becomponent/becomponent.component';

@NgModule({
  declarations: [
    AppComponent,
    ReadComponent,
    WriteComponent,
    BEComponentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    StoreModule.forRoot({
      employeeApp : employeeReducer}),
     EffectsModule.forRoot([EmployeeEffects]),
     HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

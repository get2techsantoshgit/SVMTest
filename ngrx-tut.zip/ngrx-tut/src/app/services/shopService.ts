import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Shop } from '../models/Shops';
import { shopParam } from '../models/shopParam';

@Injectable({
    providedIn: 'root'
  })

  export class ShopService{
      readonly rootUrl = 'https://localhost:58822/api';
      constructor(private _http: HttpClient){}

      getShops(formdata :shopParam):Observable<Shop>{
            return this._http.get<Shop>(this.rootUrl + '/Employees' + shopParam);
      }
  }
import { Injectable } from '@angular/core';
import { Employee } from './../models/employee.model';
import { EmployeeResponse } from './../models/EmployeeResponse';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
  })
export class EmployeeServices {
    readonly rootUrl = 'http://localhost:58822/api';

    constructor(private _http: HttpClient) { }
    
    postEmployee(formData: Employee):Observable<EmployeeResponse>{
        console.log('2');
        console.log(formData);
        return this._http.post<EmployeeResponse>(this.rootUrl + '/Employees', formData);
      }
}
import { Shop } from './models/Shops';
import { Employee } from './models/employee.model';

export interface AppState{
    readonly employee : Employee[];
    readonly shop : Shop[];
}
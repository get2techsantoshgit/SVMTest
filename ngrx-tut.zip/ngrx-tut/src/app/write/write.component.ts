import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { AppState }  from './../app.state';
import { Employee } from './../models/employee.model';
import * as EmployeeActions from './../statemanagement/actions/employee.actions';
import { Observable } from 'rxjs';
import { NgForm } from '@angular/forms';
import { nullSafeIsEquivalent } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-write',
  templateUrl: './write.component.html',
  styleUrls: ['./write.component.css']
})
export class WriteComponent implements OnInit {

  constructor(private _store: Store<AppState>) { }

  model: Employee = {
    EmployeeID:null,
    EMPCode:null,
    FullName:null,
    Mobile:null,
    Position:null
  };


  resetForm(form?: NgForm){
    if(form != null)
      form.resetForm();
      this.model = {
        EmployeeID : null,
        FullName : '',
        EMPCode : '',
        Mobile : '',
        Position:''
    }
  }

  onSubmit(form : NgForm){
    //if(form.value.EmployeeID == null)
      this.addEmployee(form);
    //else
      ///this.updateRecord(form);
    
  }
 

  addEmployee(form : NgForm){
    //console.log(form.value);
    this._store.dispatch(new EmployeeActions.AddEmployee(form.value));
  }

  ngOnInit() {
    this.resetForm();
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BEComponentComponent } from './becomponent.component';

describe('BEComponentComponent', () => {
  let component: BEComponentComponent;
  let fixture: ComponentFixture<BEComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BEComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BEComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { AppState } from './../app.state';
import { Shop } from './../models/Shops';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import * as shopAction from './../statemanagement/actions/shop.actions';
@Component({
  selector: 'app-becomponent',
  templateUrl: './becomponent.component.html',
  styleUrls: ['./becomponent.component.css']
})
export class BEComponentComponent implements OnInit {
  shops : Observable<Shop[]>;

  constructor(private store : Store<AppState>) {
    //this.shops = store.select('shopApp');
    this.store.dispatch(new shopAction.getShopsData("1"));
   }

  ngOnInit() {
  }

}

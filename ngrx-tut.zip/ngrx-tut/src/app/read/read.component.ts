import { Component, OnInit } from '@angular/core';
import { observable, Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Employee } from './../models/employee.model';
import { AppState } from './../app.state';
import { NgForm } from '@angular/forms';
import * as EmployeeActions from './../statemanagement/actions/employee.actions';

@Component({
  selector: 'app-read',
  templateUrl: './read.component.html',
  styleUrls: ['./read.component.css']
})
export class ReadComponent implements OnInit {
  employees : Observable<Employee[]>;

  constructor(private store:  Store<AppState>) { 
    this.employees = store.select('employeeApp');
    
  }

  ngOnInit() {
    
  }


  deleteEmp(id : string){
    if(confirm('Are you sure to delete')){
      //console.log(id);
    this.store.dispatch(new EmployeeActions.RemoveEmployee(id));
   }
  }
}


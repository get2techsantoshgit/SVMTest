export class shopParam {
    clientID : string;
    userId:string;
}
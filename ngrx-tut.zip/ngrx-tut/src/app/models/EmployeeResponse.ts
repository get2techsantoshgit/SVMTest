export class EmployeeResponse {
    EmployeeID: number;
    FullName : string;
    EMPCode : string;
    Mobile : string;
    Position :string;
    responseCode:string;
}
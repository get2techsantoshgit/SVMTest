import {Accounts} from './../models/Accounts';

export class Shop {
    Id :Number;
    Name : String;
    Url : String;
    accounts : Accounts[];
    responseCode:string;
}
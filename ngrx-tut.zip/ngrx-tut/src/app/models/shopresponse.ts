export class shopresponse{
    response : string;
}
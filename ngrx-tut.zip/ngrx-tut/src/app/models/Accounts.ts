export class Accounts{
    Id: Number;
    Name :string;
    Address : string;
    Country :string;
    hopId :Number;
}

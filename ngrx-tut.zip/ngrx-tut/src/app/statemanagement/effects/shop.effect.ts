import { Observable, of } from 'rxjs';
import { ShopService } from './../../services/shopService';
import { Injectable } from "@angular/core";
import { Action } from '@ngrx/store';
import { Effect, Actions, ofType} from '@ngrx/effects';
import * as ShopActions from './../actions/shop.actions';
import { switchMap, catchError ,map} from 'rxjs/operators';

@Injectable()
export class ShopEffects{
    constructor(private actions$: Actions, private shopservice: ShopService) { }

    @Effect()
    getShops$: Observable<Action> = this.actions$.pipe(
        ofType(ShopActions.GET_SHOP),
        map((action:ShopActions.getShopsData) => action.payload),
        switchMap( req => {
            return this.shopservice.getShops(req).pipe(
                map(res => {
                    if (res.responseCode == "1")
                    return  new ShopActions.getShopSuccess("Successful")}),
                    catchError(err => of( new ShopActions.getShopError(err))),
                
            );
        }))
    
}
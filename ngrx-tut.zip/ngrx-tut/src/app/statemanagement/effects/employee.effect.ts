import { EmployeeResponse } from './../../models/EmployeeResponse';
import { AddEmployee } from './../actions/employee.actions';
import { Injectable } from '@angular/core';
import { Effect, Actions, ofType} from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable , of } from 'rxjs';
import * as EmployeeActions from './../../statemanagement/actions/employee.actions';
import {  AppState } from './../../app.state';
import { Employee } from './../../models/employee.model';
import { switchMap, map, catchError } from 'rxjs/operators';
import {  EmployeeServices } from './../../services/employee.service';

@Injectable()
export class EmployeeEffects {

    constructor(private actions$: Actions, private empService: EmployeeServices) { }


    // @Effect()
    // getEmployee$: Observable<Action> = this.actions$.pipe(
    //     ofType(EmployeeActions.ADD_EMPLOYEE),
    //     switchMap((res) => { return this.empService.postEmployee(res)}  )
    // )


    @Effect()
    getEmployee$: Observable<Action> = this.actions$.pipe(
        ofType(EmployeeActions.ADD_EMPLOYEE),
        map((action: EmployeeActions.AddEmployee) => action.payload ),
        switchMap(request => { 
                return this.empService.postEmployee(request).pipe(
                    map(response  => {
                        if(response.responseCode == "1")
                        return new EmployeeActions.EmployeeSuccess(response)}),
                    catchError(error => of(new EmployeeActions.RemoveEmployee(error))),
                );
        }))
    
}
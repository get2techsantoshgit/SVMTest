import { Action, State } from '@ngrx/store';
import { Employee } from './../../models/employee.model';
import * as EmployeeActions from './../../statemanagement/actions/employee.actions';

const initialState: Employee = {
    EmployeeID : 1,
    EMPCode : '1',
    FullName: 'Santosh Singh',
    Mobile: '895689',
    Position:'SE'
}

export function employeeReducer (state: Employee[] = [initialState], action: EmployeeActions.Actions){
    switch(action.type){
        case EmployeeActions.ADD_EMPLOYEE:{
            let response = action.payload;
            //console.log(response);
            return [...state, response];

        }
        case EmployeeActions.REMOVE_EMPLOYEE:{
            let response = action.payload;
            console.log('this is remove');
            console.log(state);
            let newResult = state.splice(Number(action.payload), 1); 
            console.log(newResult);
            //let result = Object.assign({},state, newResult);
            //console.log(result);
            return newResult;
        }
        case EmployeeActions.EMPLOYEE_SUCCESS:{
            let response = action.payload;
            console.log('this is success');
            console.log(response);
            return [...state, response];

        }
        default:
            return state;
    }

}
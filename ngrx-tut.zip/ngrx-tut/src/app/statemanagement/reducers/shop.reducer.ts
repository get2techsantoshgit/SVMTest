import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Actions } from './../actions/employee.actions';
import { Employee } from './../../models/employee.model';
import { Shop } from './../../models/Shops';
import * as getShopsDataAction from './../actions/shop.actions';
import { Action, State } from '@ngrx/store';

const inititalStateShop: Shop = {
    Id : null,
    Name : null,
    Url : null,
    accounts : [],
    responseCode:""
}

export function shopReducer (state : Shop[] = [inititalStateShop], action : getShopsDataAction.Actions) {
    switch(action.type){
        case getShopsDataAction.GET_SHOP:{
            let response  = action.payload;
            return [...state, response];
        }
        case getShopsDataAction.GET_SHOP_SUCCESS:{
            let response = action.payload;
            return [...state, response];
        }
        case getShopsDataAction.GET_SHOP_ERROR:{
            let response = action.payload;
            return [...state , response];
        }
        dafault:
            return state;
    }
}


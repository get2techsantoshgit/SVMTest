import { Shop } from './../../models/Shops';
import { Action } from '@ngrx/store';
import { shopresponse } from 'src/app/models/shopresponse';
import { shopParam } from 'src/app/models/shopParam';

export const GET_SHOP = '[SHOP] GET'
export const GET_SHOP_SUCCESS = '[SHOP] Successgul'
export const GET_SHOP_ERROR = '[EMPLOYEE] Error'


export class getShopsData implements Action {
    readonly type = GET_SHOP
    constructor(public payload: shopParam){}
}

export class getShopSuccess implements Action{
    readonly type = GET_SHOP_SUCCESS
    constructor(public payload: string){}
}

export class getShopError implements Action{
    readonly type = GET_SHOP_ERROR
    constructor(public payload: string[]){}
}

export type Actions = 
  getShopsData 
| getShopSuccess 
| getShopError